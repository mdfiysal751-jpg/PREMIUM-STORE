# AI PREMIUM STORE

Python Flask + SQLite starter for a manually verified AI subscription storefront.

## Included
- Registration and login (Werkzeug password hashing)
- Product listing and admin product add/enable/disable/delete
- Checkout with personal bKash/Nagad payment instructions
- Transaction ID and sender number submission
- Admin order verification/status updates and delivery-instructions field
- Store/payment/support settings
- CSRF token check for POST forms
- Responsive templates

## Important business/compliance note
Only sell or activate subscriptions through provider-authorized reseller/partner programs or legitimate customer-owned activation flows. Do not collect customers' AI account passwords, session cookies, or 2FA codes. Verify every payment in the official bKash/Nagad app before approving it. This starter does not connect to payment APIs and does not automatically activate AI subscriptions.

## Local setup
Python 3.10+ recommended.

```bash
python -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows:
# .venv\Scripts\activate

pip install -r requirements.txt
export SECRET_KEY="$(python -c 'import secrets; print(secrets.token_hex(32))')"
export ADMIN_USERNAME="admin"
export ADMIN_PASSWORD="set-a-strong-password-here"
python app.py
```

Open http://127.0.0.1:5000 . Admin: http://127.0.0.1:5000/admin1270

On first launch, admin user is created from ADMIN_USERNAME / ADMIN_PASSWORD.
If you change ADMIN_USERNAME later, the existing admin record is not renamed automatically.

## VPS production
1. Use Ubuntu VPS and Python 3.10+.
2. Upload the folder; create a virtual environment; install requirements.
3. Set environment variables securely (never commit secrets).
4. Run behind Gunicorn + Nginx + HTTPS. Install `gunicorn` separately or add it to requirements.
5. Set `COOKIE_SECURE=1` after HTTPS is configured.
6. Configure firewall (allow SSH, HTTP/HTTPS only), automatic backups for `database.db`.
7. Use a strong unique admin password and rotate SECRET_KEY before production.

Example:
```bash
pip install gunicorn
gunicorn --workers 2 --bind 127.0.0.1:8000 app:app
```

## Current limitations / next production steps
- No email verification, password reset, rate limiting, audit log, or automatic payment API verification.
- Add database migrations and a proper admin role table before multi-admin use.
- Do not use this as a payment gateway; it is a manual receipt workflow.
