import os
import sqlite3
import secrets
from functools import wraps
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, session, flash, abort
from werkzeug.security import generate_password_hash, check_password_hash

APP_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.environ.get("DB_PATH", os.path.join(APP_DIR, "database.db"))
SECRET_KEY = os.environ.get("SECRET_KEY", "CHANGE_ME_TO_A_LONG_RANDOM_SECRET")
ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "admin")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "ChangeThisAdminPassword123!")

app = Flask(__name__)
app.secret_key = SECRET_KEY
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
                  SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "0") == "1")
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    with db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS users(
          id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
          email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
          created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS products(
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
          description TEXT NOT NULL DEFAULT '', duration TEXT NOT NULL DEFAULT '1 month',
          price REAL NOT NULL CHECK(price>=0), active INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS orders(
          id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
          product_id INTEGER, product_name TEXT NOT NULL, duration TEXT NOT NULL,
          amount REAL NOT NULL, payment_method TEXT NOT NULL,
          sender_number TEXT NOT NULL, trx_id TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'Payment Submitted',
          delivery TEXT NOT NULL DEFAULT '', admin_note TEXT NOT NULL DEFAULT '',
          created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
          FOREIGN KEY(user_id) REFERENCES users(id));
        CREATE TABLE IF NOT EXISTS settings(
          key TEXT PRIMARY KEY, value TEXT NOT NULL);
        """)
        defaults = {
            "store_name":"AI PREMIUM STORE",
            "bkash_number":"01XXXXXXXXX",
            "nagad_number":"01XXXXXXXXX",
            "payment_instructions":"Send the exact amount using Send Money, then submit the Transaction ID. Orders are manually verified.",
            "support_contact":"@your_support"
        }
        for k,v in defaults.items():
            con.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)",(k,v))
        if not con.execute("SELECT id FROM users WHERE username=?",(ADMIN_USERNAME,)).fetchone():
            con.execute("INSERT INTO users(username,email,password_hash,created_at) VALUES(?,?,?,?)",
                (ADMIN_USERNAME, "admin@localhost", generate_password_hash(ADMIN_PASSWORD), now()))
        if con.execute("SELECT COUNT(*) FROM products").fetchone()[0] == 0:
            samples=[
              ("ChatGPT Plus","Access provisioned by the store admin. Availability and terms must be confirmed before purchase.","1 month",1500),
              ("Gemini Pro","Google AI subscription activation handled by admin.","1 month",1200),
              ("Claude Pro","Claude subscription activation handled by admin.","1 month",1800),
              ("Perplexity Pro","Perplexity subscription activation handled by admin.","1 month",1300),
              ("Other AI Subscription","Tell admin which eligible AI plan you need.","Custom",0)
            ]
            for name,desc,duration,price in samples:
                con.execute("INSERT INTO products(name,description,duration,price,active,created_at) VALUES(?,?,?,?,1,?)",
                            (name,desc,duration,price,now()))
def now():
    return datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")

def setting(key, default=""):
    with db() as con:
        row=con.execute("SELECT value FROM settings WHERE key=?",(key,)).fetchone()
    return row["value"] if row else default

def csrf_token():
    if "_csrf" not in session:
        session["_csrf"]=secrets.token_urlsafe(32)
    return session["_csrf"]
app.jinja_env.globals["csrf_token"] = csrf_token

@app.before_request
def csrf_protect():
    if request.method == "POST":
        token=request.form.get("_csrf","")
        if not token or token != session.get("_csrf"):
            abort(400, "Invalid CSRF token. Refresh and try again.")

def login_required(f):
    @wraps(f)
    def wrapped(*args,**kwargs):
        if not session.get("user_id"):
            flash("Please log in first.", "warning")
            return redirect(url_for("login"))
        return f(*args,**kwargs)
    return wrapped

def admin_required(f):
    @wraps(f)
    def wrapped(*args,**kwargs):
        if not session.get("user_id") or not session.get("is_admin"):
            abort(404)
        return f(*args,**kwargs)
    return wrapped

@app.context_processor
def inject_globals():
    return {"store_name":setting("store_name","AI PREMIUM STORE"),
            "current_user":session.get("username")}

@app.route("/")
def index():
    with db() as con:
        products=con.execute("SELECT * FROM products WHERE active=1 ORDER BY id DESC").fetchall()
    return render_template("index.html",products=products)

@app.route("/register",methods=["GET","POST"])
def register():
    if request.method=="POST":
        username=request.form.get("username","").strip()
        email=request.form.get("email","").strip().lower()
        password=request.form.get("password","")
        if len(username)<3 or len(password)<8 or "@" not in email:
            flash("Username needs 3+ characters, valid email, password needs 8+ characters.","danger")
        else:
            try:
                with db() as con:
                    con.execute("INSERT INTO users(username,email,password_hash,created_at) VALUES(?,?,?,?)",
                               (username,email,generate_password_hash(password),now()))
                flash("Account created. Please log in.","success")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                flash("Username or email already exists.","danger")
    return render_template("auth.html",mode="register")

@app.route("/login",methods=["GET","POST"])
def login():
    if request.method=="POST":
        identity=request.form.get("identity","").strip()
        password=request.form.get("password","")
        with db() as con:
            user=con.execute("SELECT * FROM users WHERE username=? OR email=?",(identity,identity.lower())).fetchone()
        if user and check_password_hash(user["password_hash"],password):
            session.clear()
            session["user_id"]=user["id"]
            session["username"]=user["username"]
            session["is_admin"]=(user["username"]==ADMIN_USERNAME)
            flash("Welcome back!","success")
            return redirect(url_for("admin_dashboard") if session["is_admin"] else url_for("index"))
        flash("Invalid credentials.","danger")
    return render_template("auth.html",mode="login")

@app.route("/logout",methods=["POST"])
@login_required
def logout():
    session.clear()
    flash("Logged out.","success")
    return redirect(url_for("index"))

@app.route("/checkout/<int:product_id>",methods=["GET","POST"])
@login_required
def checkout(product_id):
    with db() as con:
        product=con.execute("SELECT * FROM products WHERE id=? AND active=1",(product_id,)).fetchone()
    if not product: abort(404)
    if request.method=="POST":
        method=request.form.get("payment_method","")
        sender=request.form.get("sender_number","").strip()
        trx=request.form.get("trx_id","").strip()
        if method not in ("bKash","Nagad") or len(sender)<8 or len(trx)<4:
            flash("Please enter a valid payment method, sender number and Transaction ID.","danger")
        else:
            stamp=now()
            with db() as con:
                con.execute("""INSERT INTO orders(user_id,product_id,product_name,duration,amount,payment_method,
                sender_number,trx_id,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (session["user_id"],product["id"],product["name"],product["duration"],product["price"],
                 method,sender,trx,"Payment Submitted",stamp,stamp))
            flash("Order submitted. Admin will verify your payment.","success")
            return redirect(url_for("my_orders"))
    return render_template("checkout.html",product=product,
        bkash_number=setting("bkash_number"),nagad_number=setting("nagad_number"),
        payment_instructions=setting("payment_instructions"))

@app.route("/my-orders")
@login_required
def my_orders():
    with db() as con:
        orders=con.execute("SELECT * FROM orders WHERE user_id=? ORDER BY id DESC",(session["user_id"],)).fetchall()
    return render_template("my_orders.html",orders=orders)

@app.route("/admin1270")
@admin_required
def admin_dashboard():
    with db() as con:
        stats={
          "users":con.execute("SELECT COUNT(*) FROM users WHERE username!=?",(ADMIN_USERNAME,)).fetchone()[0],
          "orders":con.execute("SELECT COUNT(*) FROM orders").fetchone()[0],
          "pending":con.execute("SELECT COUNT(*) FROM orders WHERE status='Payment Submitted'").fetchone()[0],
          "sales":con.execute("SELECT COALESCE(SUM(amount),0) FROM orders WHERE status='Completed'").fetchone()[0],
        }
        orders=con.execute("SELECT o.*,u.username FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.id DESC LIMIT 50").fetchall()
        products=con.execute("SELECT * FROM products ORDER BY id DESC").fetchall()
    return render_template("admin/dashboard.html",stats=stats,orders=orders,products=products)

@app.route("/admin1270/products",methods=["GET","POST"])
@admin_required
def admin_products():
    if request.method=="POST":
        action=request.form.get("action")
        try:
            with db() as con:
                if action=="add":
                    price=float(request.form.get("price","0"))
                    if price<0: raise ValueError()
                    con.execute("INSERT INTO products(name,description,duration,price,active,created_at) VALUES(?,?,?,?,?,?)",
                      (request.form["name"].strip(),request.form.get("description","").strip(),
                       request.form.get("duration","1 month").strip(),price,1,now()))
                elif action=="toggle":
                    con.execute("UPDATE products SET active=1-active WHERE id=?",(int(request.form["id"]),))
                elif action=="delete":
                    con.execute("DELETE FROM products WHERE id=?",(int(request.form["id"]),))
            flash("Product updated.","success")
        except (ValueError,KeyError):
            flash("Please check product details and price.","danger")
        return redirect(url_for("admin_products"))
    with db() as con:
        products=con.execute("SELECT * FROM products ORDER BY id DESC").fetchall()
    return render_template("admin/products.html",products=products)

@app.route("/admin1270/orders")
@admin_required
def admin_orders():
    with db() as con:
        orders=con.execute("SELECT o.*,u.username FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.id DESC").fetchall()
    return render_template("admin/orders.html",orders=orders)

@app.route("/admin1270/orders/<int:order_id>",methods=["POST"])
@admin_required
def admin_order_update(order_id):
    status=request.form.get("status","")
    allowed={"Payment Submitted","Payment Verified","Processing","Completed","Rejected"}
    if status not in allowed: abort(400)
    delivery=request.form.get("delivery","").strip()
    note=request.form.get("admin_note","").strip()
    with db() as con:
        order=con.execute("SELECT id FROM orders WHERE id=?",(order_id,)).fetchone()
        if not order: abort(404)
        con.execute("UPDATE orders SET status=?,delivery=?,admin_note=?,updated_at=? WHERE id=?",
                    (status,delivery,note,now(),order_id))
    flash("Order saved.","success")
    return redirect(url_for("admin_orders"))

@app.route("/admin1270/settings",methods=["GET","POST"])
@admin_required
def admin_settings():
    keys=["store_name","bkash_number","nagad_number","payment_instructions","support_contact"]
    if request.method=="POST":
        with db() as con:
            for key in keys:
                con.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                           (key,request.form.get(key,"").strip()))
        flash("Settings saved.","success")
        return redirect(url_for("admin_settings"))
    return render_template("admin/settings.html",values={k:setting(k) for k in keys})

@app.errorhandler(404)
def not_found(e):
    return render_template("404.html"),404

init_db()
if __name__=="__main__":
    app.run(host="0.0.0.0",port=int(os.environ.get("PORT","5000")),debug=False)
